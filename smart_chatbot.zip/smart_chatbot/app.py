from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import sqlite3, re, random, os

app = Flask(__name__)
app.secret_key = "smartchatbot_secret_2025"
DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "chatbot.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            created TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS chats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            user_msg TEXT NOT NULL,
            bot_reply TEXT NOT NULL,
            timestamp TEXT DEFAULT (datetime('now')),
            FOREIGN KEY(user_id) REFERENCES users(id)
        );
        """)

KNOWLEDGE_BASE = [
    (["hello","hi","hey","howdy","greetings","sup","salam","assalam"],
     ["Hello! 👋 Great to see you. What's on your mind?",
      "Hey there! I'm ready to help. What would you like to talk about?",
      "Hi! I'm SmartBot — your offline AI assistant. Ask me anything!",
      "Greetings! How can I assist you today? 😊"]),

    (["bye","goodbye","see you","later","take care","exit","quit","khuda hafiz"],
     ["Goodbye! 👋 It was great chatting with you!",
      "See you later! Come back anytime you need help.",
      "Take care! I'll be here whenever you need me. 😊",
      "Bye! Have a wonderful day ahead! 🌟"]),

    (["how are you","how r u","you ok","you good","kaisa hai"],
     ["I'm doing great, thanks for asking! 😊 How about you?",
      "I'm functioning perfectly and ready to help! How are you doing?",
      "All systems running smoothly! How can I assist you today?"]),

    (["your name","who are you","what are you","introduce yourself","aap kaun"],
     ["I'm **SmartBot** — your intelligent offline AI assistant! 🤖",
      "I'm SmartBot, built with Python NLP logic. No internet needed!",
      "My name is SmartBot. I'm here to answer your questions and have great conversations! 💬"]),

    (["artificial intelligence","machine learning","deep learning","neural network","ml","algorithm"],
     ["**Artificial Intelligence (AI)** is the simulation of human intelligence in machines. It includes Machine Learning, Deep Learning, NLP, and Computer Vision. 🤖",
      "**Machine Learning** is a subset of AI where machines learn from data without being explicitly programmed. Algorithms improve with experience!",
      "**Deep Learning** uses neural networks with many layers to learn complex patterns — it powers image recognition, speech, and chatbots!",
      "AI is transforming every industry — healthcare, finance, education, and more. It's the most exciting technology of our era! 🚀"]),

    (["python","programming","code","coding","software","developer","script"],
     ["**Python** is one of the most popular programming languages! 🐍 It's used in AI, web development, data science, and automation.",
      "Python was created by Guido van Rossum in 1991. Its simple syntax makes it perfect for beginners and experts alike.",
      "Python libraries like **Flask, NumPy, Pandas, TensorFlow** make it the #1 language for AI and data science!",
      "Learning Python? Start with: variables → loops → functions → OOP → Flask for web apps! 📚"]),

    (["flask","web framework","web development","backend","django","api","route"],
     ["**Flask** is a lightweight Python web framework. Perfect for building web apps and REST APIs quickly! 🌐",
      "Flask uses **routes, Jinja2 templates,** and extensions. Very easy to learn!",
      "Flask vs Django: Flask is minimal and flexible, Django is full-featured for large projects.",
      "This chatbot is built with Flask! The backend handles routes, sessions, and chat history. 💻"]),

    (["nlp","natural language","text processing","tokenization","sentiment","chatbot"],
     ["**Natural Language Processing (NLP)** is AI that helps computers understand human language. It powers chatbots, translation, and spell check! 💬",
      "NLP techniques include: **tokenization, stemming, sentiment analysis,** and named entity recognition.",
      "Famous NLP models: BERT, GPT, T5 — trained on billions of text examples!",
      "This chatbot uses **rule-based NLP** — keyword detection + pattern matching — to give smart responses! 🧠"]),

    (["study","exam","learn","education","university","college","school","student","lecture","test"],
     ["📚 **Study tips:** Break sessions into 25-min Pomodoros, take breaks, review notes within 24 hours, sleep 8 hours!",
      "For exams: Start revision **2 weeks early**, practice past papers, teach concepts to others!",
      "🧠 Use **spaced repetition, active recall,** and mind maps to retain information better.",
      "University tip: Attend lectures, form study groups, visit professors during office hours!"]),

    (["health","diet","food","nutrition","healthy","fitness","exercise","workout","gym"],
     ["🥗 A balanced diet includes: **proteins** (chicken, eggs), **carbs** (rice, bread), **healthy fats** (nuts, avocado), and vegetables.",
      "💪 30 minutes of exercise daily! Mix **cardio** with **strength training** for best results.",
      "Drink **8 glasses of water** daily, sleep 7-9 hours, eat more fruits and reduce processed food!",
      "Fill **half** your plate with vegetables, **quarter** with protein, **quarter** with whole grains! 🥦"]),

    (["stress","anxiety","depression","mental health","sad","worried","overthinking","pressure"],
     ["I'm sorry you're feeling stressed. 💙 Try **deep breathing** — inhale 4s, hold 4s, exhale 4s.",
      "Mental health matters! Talk to someone you trust, write in a journal, exercise, and limit social media.",
      "Stress tip: Focus on **what's in your control**, and let go of the rest. You've got this! 💪",
      "Bad days don't last forever. Be kind to yourself and take things one step at a time. 🌟"]),

    (["motivat","inspire","quote","discourage","give up","hopeless","confidence","believe"],
     ["💡 **\"The secret of getting ahead is getting started.\"** — Mark Twain",
      "🔥 **\"Success is not final, failure is not fatal. The courage to continue counts.\"** — Churchill",
      "🌟 Every expert was once a beginner. **Keep going!**",
      "✨ **\"Don't watch the clock; do what it does. Keep going.\"** — Sam Levenson"]),

    (["pakistan","lahore","karachi","islamabad","punjab","superior university"],
     ["Pakistan is a beautiful country with rich culture and incredibly talented people! 🇵🇰",
      "**Lahore** is the cultural capital of Pakistan — famous for food, Mughal architecture, and warm people! 🕌",
      "**The Superior University Lahore** is one of Pakistan's top universities for CS and AI programs! 🎓",
      "Pakistan has **K2** (world's 2nd highest peak) and a booming tech industry! 🏔️"]),

    (["weather","temperature","rain","sunny","cold","hot","climate"],
     ["I don't have live weather data — check **weather.com** or Google 'weather [your city]' for updates! ☀️",
      "Weather fact: The hottest temp ever recorded was **56.7°C** in Death Valley, California! 🌡️"]),

    (["time","date","today","what day","current time","aaj"],
     [f"The current date and time is: **{datetime.now().strftime('%A, %B %d, %Y — %I:%M %p')}** ⏰",
      f"Today is **{datetime.now().strftime('%A, %d %B %Y')}**. Hope you're having a great day! 😊"]),

    (["math","calculate","algebra","geometry","calculus","statistics","formula"],
     ["📐 Practice daily, understand concepts before memorising formulas, use **Khan Academy** for free lessons!",
      "**Statistics:** Mean (average), Median (middle), Mode (most frequent), Std Deviation (spread of data).",
      "Algebra tip: Always do the **same operation on both sides** to isolate the variable!"]),

    (["science","physics","chemistry","biology","astronomy","space","universe"],
     ["🔬 Science is the pursuit of knowledge through observation and experimentation!",
      "**Space fact:** Light from the Sun takes ~8 minutes to reach Earth. Nearest star is **4.24 light years** away! 🌌",
      "Chemistry is central to everything — medicine, materials, energy, and food rely on chemical processes. ⚗️"]),

    (["joke","funny","laugh","humor","entertain","comedy"],
     ["😄 Why do programmers prefer dark mode? Because **light attracts bugs!**",
      "🤣 Why did the scarecrow win an award? He was **outstanding in his field!**",
      "😂 I told my computer I needed a break. Now it sends me **Kit-Kat ads!**",
      "😆 Why do Python programmers prefer snakes? They have **great syntax!**",
      "🤓 A SQL query walks into a bar and asks two tables: **'Can I join you?'**"]),

    (["thank","thanks","appreciate","helpful","great","well done","nice"],
     ["You're very welcome! 😊 Happy to help anytime!",
      "Glad I could help! Don't hesitate to ask more questions. 🙌",
      "Thank YOU for the kind words! Anything else I can assist with? 💪"]),

    (["career","job","work","employment","salary","intern","resume","cv","interview"],
     ["💼 **Career tips:** Build a portfolio, network on LinkedIn, practice interviews, and keep learning!",
      "For a great resume: **1-2 pages**, action verbs, quantify achievements, tailor it per job.",
      "**Top skills in 2025:** AI/ML, data analysis, communication, problem-solving, adaptability."]),

    (["book","read","novel","author","literature","library","reading"],
     ["📖 Reading improves vocabulary, reduces stress, builds empathy, and makes you a better thinker!",
      "**Must-read books:** Atomic Habits (Clear), Think and Grow Rich (Hill), The Alchemist (Coelho).",
      "**Reading tip:** 20 pages daily = 7,300 pages/year = about 20-30 books! 📚"]),

    (["sport","cricket","football","soccer","basketball","tennis","match"],
     ["🏏 Cricket is the most popular sport in Pakistan — it unifies the entire nation!",
      "⚽ Football is the world's most popular sport with over **4 billion fans** globally.",
      "Sports improve mental health, build teamwork, and keep you fit and energised! 💪"]),

    (["love","relationship","girlfriend","boyfriend","marriage","crush","heart"],
     ["💕 Healthy relationships are built on **trust, communication, respect,** and support.",
      "Love tip: Listen more than you talk, be honest, and show appreciation for small things.",
      "The best advice: Never go to bed angry and always celebrate each other's wins! ❤️"]),
]

FALLBACKS = [
    "That's an interesting question! 🤔 Could you elaborate a bit more?",
    "Hmm, I'm not sure about that. Try asking about **AI, Python, health, study tips,** or **careers!**",
    "Great question! 💡 I'd suggest exploring it on Wikipedia or Google for more details.",
    "I'm an offline chatbot with curated knowledge. Ask about **science, technology, motivation,** or **education!**",
    "Interesting! I might not know everything, but I'm always here to chat and help. 😊",
    "Try asking about **AI, Python, NLP, health,** or **career tips** — I excel at those! 🤖",
]

def preprocess(text):
    text = text.lower().strip()
    text = re.sub(r"[^\w\s]", " ", text)
    return text

def get_response(user_input):
    cleaned = preprocess(user_input)
    words   = cleaned.split()
    best_score = 0
    best_entry = None
    for keywords, responses in KNOWLEDGE_BASE:
        score = 0
        for kw in keywords:
            if kw in cleaned:
                score += 2
            elif any(kw in w for w in words):
                score += 1
        if score > best_score:
            best_score = score
            best_entry = responses
    if best_entry and best_score > 0:
        return random.choice(best_entry)
    try:
        expr = re.sub(r"[^0-9+\-*/().\s]", "", user_input).strip()
        if expr and any(op in expr for op in "+-*/") and len(expr) > 1:
            result = eval(expr)
            return f"🧮 The answer is: **{result}**"
    except Exception:
        pass
    return random.choice(FALLBACKS)

@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("chat"))
    return redirect(url_for("login"))

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        data     = request.get_json()
        username = data.get("username","").strip()
        password = data.get("password","")
        with get_db() as conn:
            user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and check_password_hash(user["password"], password):
            session["user_id"]  = user["id"]
            session["username"] = user["username"]
            return jsonify({"success": True})
        return jsonify({"success": False, "error": "Invalid username or password."}), 401
    return render_template("login.html")

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        data     = request.get_json()
        username = data.get("username","").strip()
        email    = data.get("email","").strip()
        password = data.get("password","")
        if not username or not email or not password:
            return jsonify({"success": False, "error": "All fields are required."}), 400
        if len(password) < 6:
            return jsonify({"success": False, "error": "Password must be at least 6 characters."}), 400
        with get_db() as conn:
            if conn.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone():
                return jsonify({"success": False, "error": "Username already taken."}), 409
            if conn.execute("SELECT id FROM users WHERE email=?", (email,)).fetchone():
                return jsonify({"success": False, "error": "Email already registered."}), 409
            conn.execute("INSERT INTO users (username,email,password) VALUES (?,?,?)",
                         (username, email, generate_password_hash(password)))
        return jsonify({"success": True})
    return render_template("register.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/chat")
def chat():
    if "user_id" not in session:
        return redirect(url_for("login"))
    return render_template("chat.html", username=session["username"])

@app.route("/api/message", methods=["POST"])
def api_message():
    if "user_id" not in session:
        return jsonify({"error": "Unauthorized"}), 401
    data     = request.get_json()
    user_msg = (data.get("message") or "").strip()
    if not user_msg:
        return jsonify({"error": "Empty message"}), 400
    bot_reply = get_response(user_msg)
    ts        = datetime.now().strftime("%I:%M %p")
    with get_db() as conn:
        conn.execute("INSERT INTO chats (user_id,user_msg,bot_reply,timestamp) VALUES (?,?,?,?)",
                     (session["user_id"], user_msg, bot_reply, ts))
    return jsonify({"reply": bot_reply, "timestamp": ts})

@app.route("/api/history")
def api_history():
    if "user_id" not in session:
        return jsonify([])
    with get_db() as conn:
        rows = conn.execute(
            "SELECT user_msg,bot_reply,timestamp FROM chats WHERE user_id=? ORDER BY id ASC LIMIT 100",
            (session["user_id"],)
        ).fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/api/clear_history", methods=["POST"])
def clear_history():
    if "user_id" not in session:
        return jsonify({"error": "Unauthorized"}), 401
    with get_db() as conn:
        conn.execute("DELETE FROM chats WHERE user_id=?", (session["user_id"],))
    return jsonify({"success": True})

@app.route("/api/stats")
def api_stats():
    if "user_id" not in session:
        return jsonify({})
    with get_db() as conn:
        total = conn.execute("SELECT COUNT(*) FROM chats WHERE user_id=?", (session["user_id"],)).fetchone()[0]
        user  = conn.execute("SELECT username,created FROM users WHERE id=?", (session["user_id"],)).fetchone()
    created = user["created"][:7] if user else ""
    try:
        dt = datetime.strptime(created, "%Y-%m")
        created = dt.strftime("%b %Y")
    except Exception:
        pass
    return jsonify({
        "total_messages": total,
        "member_since":   created,
        "username":       user["username"] if user else "",
    })

if __name__ == "__main__":
    init_db()
    print("\n" + "="*50)
    print("  SmartBot is RUNNING!")
    print("  Open: http://localhost:5000")
    print("="*50 + "\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
