# 🤖 Smart Offline AI Chatbot
### Flask + Rule-Based NLP + SQLite — No API Required

---

## 🚀 HOW TO RUN (Step by Step)

### Step 1 — Install dependencies
Open CMD in the project folder and run:
```
pip install -r requirements.txt
```

### Step 2 — Run the app
```
python app.py
```

### Step 3 — Open browser
Go to: http://localhost:5000

### Step 4 — Register an account
Click "Create one free" → fill in username, email, password → login

---

## ✅ Features
- Login / Register system with password hashing
- SQLite database (auto-created on first run)
- Smart NLP keyword detection (25+ topic categories)
- Chat history saved per user
- Dark mode UI with chat bubbles
- Typing animation
- Suggestion chips
- Copy / Download
- No internet / No API needed — works 100% offline

---

## 📁 Project Structure
```
smart_chatbot/
├── app.py                  ← Flask backend + NLP engine
├── requirements.txt        ← Python dependencies
├── README.md
├── instance/
│   └── chatbot.db          ← SQLite DB (auto-created)
├── templates/
│   ├── login.html
│   ├── register.html
│   └── chat.html
└── static/
    ├── css/chat.css
    └── js/chat.js
```

## 🧠 Topics SmartBot Knows
AI/ML, Python, Flask, NLP, Study Tips, Health/Diet, Mental Health,
Technology, Career, Motivation, Pakistan/Lahore, Math, Science,
Music, Sports, Books, Weather, Time/Date, Jokes, Love/Relationships,
and more!
