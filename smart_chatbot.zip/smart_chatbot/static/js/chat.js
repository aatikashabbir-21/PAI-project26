/* ══════════════════════════════════════════════════
   SMARTBOT CHAT — JAVASCRIPT
   ══════════════════════════════════════════════════ */
(function(){
"use strict";

const chatWindow = document.getElementById("chatWindow");
const messages   = document.getElementById("messages");
const userInput  = document.getElementById("userInput");
const sendBtn    = document.getElementById("sendBtn");
const typing     = document.getElementById("typing");
const welcome    = document.getElementById("welcome");
const charDisplay = document.getElementById("charDisplay");

// ── Load stats + history on start ─────────────────────────────────────────
(async function init(){
  loadStats();
  loadHistory();
})();

async function loadStats(){
  try{
    const r = await fetch("/api/stats");
    const d = await r.json();
    if(d.username){
      document.getElementById("sidebarUsername").textContent = d.username;
      document.getElementById("avatarLetter").textContent    = d.username[0].toUpperCase();
      document.getElementById("statMessages").textContent    = d.total_messages;
      document.getElementById("statSince").textContent       = d.member_since;
      document.getElementById("sidebarMeta").textContent     = "Member since " + d.member_since;
    }
  }catch(e){ /* silent */ }
}

async function loadHistory(){
  try{
    const r = await fetch("/api/history");
    const history = await r.json();
    if(history.length){
      welcome.classList.add("hidden");
      history.forEach(item => {
        appendMessage(item.user_msg, "user", item.timestamp);
        appendMessage(item.bot_reply, "bot",  item.timestamp);
      });
      scrollBottom();
    }
  }catch(e){ /* silent */ }
}

// ── Character counter ──────────────────────────────────────────────────────
userInput.addEventListener("input", () => {
  const len = userInput.value.length;
  charDisplay.textContent = len + " / 500";
  charDisplay.style.color = len > 450 ? "#f87171" : "";
  if(len > 500) userInput.value = userInput.value.slice(0, 500);
});

// ── Enter key ─────────────────────────────────────────────────────────────
userInput.addEventListener("keydown", e => {
  if(e.key === "Enter" && !e.shiftKey){ e.preventDefault(); sendMessage(); }
});

// ── Auto resize textarea ───────────────────────────────────────────────────
function autoResize(el){
  el.style.height = "auto";
  el.style.height = Math.min(el.scrollHeight, 120) + "px";
}
userInput.addEventListener("input", () => autoResize(userInput));
window.autoResize = autoResize;

// ── Send message ──────────────────────────────────────────────────────────
async function sendMessage(){
  const text = userInput.value.trim();
  if(!text || sendBtn.disabled) return;

  // hide welcome
  welcome.classList.add("hidden");

  // show user msg
  appendMessage(text, "user", nowTime());
  userInput.value = "";
  userInput.style.height = "auto";
  charDisplay.textContent = "0 / 500";

  // lock input
  sendBtn.disabled = true;
  userInput.disabled = true;

  // show typing
  typing.classList.remove("hidden");
  scrollBottom();

  try{
    const r = await fetch("/api/message", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text })
    });
    const d = await r.json();

    typing.classList.add("hidden");

    if(d.reply){
      appendMessage(d.reply, "bot", d.timestamp || nowTime());
      updateStatCount(1);
    } else {
      appendMessage("Something went wrong. Please try again.", "bot", nowTime());
    }
  }catch(err){
    typing.classList.add("hidden");
    appendMessage("Oops! Something went wrong.", "bot", nowTime());
  }

  sendBtn.disabled = false;
  userInput.disabled = false;
  userInput.focus();
  scrollBottom();
}
window.sendMessage = sendMessage;

// ── Append a message bubble ───────────────────────────────────────────────
function appendMessage(text, type, time){
  const row = document.createElement("div");
  row.className = "msg-row " + (type === "user" ? "user-row" : "");

  const av = document.createElement("div");
  av.className = "msg-avatar " + (type === "user" ? "user-av" : "bot-av");
  av.textContent = type === "user" ? "👤" : "🤖";

  const bubble = document.createElement("div");
  bubble.className = "bubble " + (type === "user" ? "user-bubble" : "bot-bubble");

  // format bold (**text**) and line breaks
  bubble.innerHTML = escHtml(text)
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/\n/g, "<br/>");

  const timeEl = document.createElement("span");
  timeEl.className = "bubble-time";
  timeEl.textContent = time || nowTime();
  bubble.appendChild(timeEl);

  row.appendChild(av);
  row.appendChild(bubble);
  messages.appendChild(row);
}

// ── Suggestion chips ──────────────────────────────────────────────────────
function sendSuggestion(btn){
  userInput.value = btn.textContent;
  if(window.innerWidth < 768) toggleSidebar();
  sendMessage();
}
window.sendSuggestion = sendSuggestion;

// ── Clear history ─────────────────────────────────────────────────────────
async function clearHistory(){
  if(!confirm("Clear all chat history?")) return;
  await fetch("/api/clear_history", { method: "POST" });
  messages.innerHTML = "";
  welcome.classList.remove("hidden");
  document.getElementById("statMessages").textContent = "0";
}
window.clearHistory = clearHistory;

// ── Sidebar toggle ────────────────────────────────────────────────────────
function toggleSidebar(){
  document.getElementById("sidebar").classList.toggle("open");
}
window.toggleSidebar = toggleSidebar;

// ── Helpers ───────────────────────────────────────────────────────────────
function scrollBottom(){
  setTimeout(() => { chatWindow.scrollTop = chatWindow.scrollHeight; }, 50);
}
function nowTime(){
  return new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"});
}
function escHtml(str){
  return str.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}
function updateStatCount(n){
  const el = document.getElementById("statMessages");
  el.textContent = (parseInt(el.textContent)||0) + n;
}

})();
